import "./bootstrap";
import.meta.glob(["../images/iceCream.jpg"]);
